// Set camera preset values here.  For each preset, the first set of values is
// for the left column, and the second set of values is for the right column.
var CameraPresets = {
  preset1: [
    { Plownumber: -1854, Phighnumber: -1258, Tlownumber: -657, Thighnumber: 12339, Zlownumber: 51468, Zhighnumber: 64711 },
    { Plownumber: -10603, Phighnumber: 74, Tlownumber: -14364, Thighnumber: -3627, Zlownumber: 74271, Zhighnumber: 150835 }
  ],
  preset2: [
    { Plownumber: -16277, Phighnumber: -12267, Tlownumber: -14402, Thighnumber: 11052, Zlownumber: 131714, Zhighnumber: 219794 },
    { Plownumber: -13149, Phighnumber: -6575, Tlownumber: -9813, Thighnumber: 1392, Zlownumber: 140826, Zhighnumber: 162393 }
  ],
  preset3: [
    { Plownumber: -9481, Phighnumber: 12514, Tlownumber: -6998, Thighnumber: -187, Zlownumber: 164451, Zhighnumber: 194106 },
    { Plownumber: -10197, Phighnumber: -1905, Tlownumber: -5594, Thighnumber: 7405, Zlownumber: 186608, Zhighnumber: 275870 }
  ],
  preset4: [
    { Plownumber: -7584, Phighnumber: 8831, Tlownumber: 11523, Thighnumber: 15369, Zlownumber: 254, Zhighnumber: 162396 },
    { Plownumber: -7470, Phighnumber: 12938, Tlownumber: -10398, Thighnumber: 4867, Zlownumber: 57431, Zhighnumber: 152027 }
  ]
};

// Utility Function for making a random pre-set.  Not used in code anywhere, but useful for developing
function RandomizedPreset() {
  var p, z, t;

  p = [ Math.floor(Math.random() * 34000) -17000, Math.floor(Math.random() * 34000) -17000 ];
  t = [ Math.floor(Math.random() * 34000) -17000, Math.floor(Math.random() * 34000) -17000 ];
  z = [ Math.floor(Math.random() * 300000) + 1, Math.floor(Math.random() * 300000) + 1 ];

  return {
    Plownumber: Math.min(p[0], p[1]),
    Phighnumber: Math.max(p[0], p[1]),
    Tlownumber: Math.min(t[0],t[1]),
    Thighnumber: Math.max(t[0], t[1]),
    Zlownumber: Math.min(z[0], z[1]),
    Zhighnumber: Math.max(z[0], z[1])
  };
}

function IsNumeric(n) {
  return !isNaN(n);
}

function SafeNextIndex(array, currentIndex) {
  // Return next index, or loop back to 0 if next is out of bounds.
  return (currentIndex + 1 >= array.length) ? 0 : currentIndex + 1;
}

function RandomIntervalInMS(min, max) {
  return Math.floor((Math.random() * max) + min) * 1000;
}

function ParsedIntOf(input) {
  var parsed = parseInt($(input).val());
  return (IsNumeric(parsed)) ? parsed : NaN;
}

function ParsedFloatOf(input) {
  var parsed = parseFloat($(input).val());
  return (IsNumeric(parsed)) ? parsed : NaN;
}

function ParsePreset(inputGroup) {
  return {
    index: ParsedIntOf($(inputGroup).find('.index')),
    period: ParsedIntOf($(inputGroup).find('.period'))
  };
}

function CollectLoop2Presets() {
  return $.makeArray($(".loop2Preset"));
}

function UpdatePresets(presets, currentIndex) {
  if(IsLoop2Enabled()) {
    PopulatePreset("preset" + presets[currentIndex].index);
    DisplayNextPresetPeriod(presets, currentIndex);
    $("#getit").click();
    ScheduleUpdatePresets(presets, currentIndex);
  }
}

function Loop2InnerEvent(currentLoopInterval) {
  DisplayLoop2InnerLoopPeriod(currentLoopInterval);
  $("#getit").click();
}

function ScheduleLoop2InnerEvent() {
  // Inner event loop. Controls when random interval where we click the 'generate' button.
  var innerLoopMinInterval = 1,
    innerLoopMaxInterval = 10, // could be the max interval on this loops setting
    currentLoopInterval = RandomIntervalInMS(innerLoopMinInterval, innerLoopMaxInterval);

  window.loop2InnerTimer = window.setTimeout(function () {
    Loop2InnerEvent(currentLoopInterval);
  }, currentLoopInterval);
}

function ScheduleUpdatePresets(presets, currentIndex) {
  // Outer event loop.  Controls when we change rows in Loop2; e.g., which preset.
  return window.setTimeout(function () {
    UpdatePresets(presets, SafeNextIndex(presets, currentIndex));
  }, presets[currentIndex].period * 1000);
}

function StartUpdatePresetsLoop(presets) {
  // first run (at 0ms);
  UpdatePresets(presets, 0);
  RandomlyTimedButtonClick2(1,10);

  // subsequent 'timed' runs
  window.loop2EventLoop = ScheduleUpdatePresets(presets, 1);
}

function StopUpdatePresetsLoop() {
  window.clearTimeout(window.loop2EventLoop);
  window.clearTimeout(window.randomlyTimedButtonClick);
}

function DisplayNextPresetPeriod(presets, index) {
  var interval = presets[index].period,
      currentIndex = index + 1,
      nextIndex = SafeNextIndex(presets, index) + 1;
  $("#Loop2PresetNextChange").html("Currently using row " + currentIndex + ".  Switching to row " +  nextIndex + " in " + interval + " seconds.");
}

function DisplayLoop2InnerLoopPeriod(interval) {
  $("#Loop2ButtonNextClick").html("The next preset button click is in: " + interval/1000 + " seconds.");
}

function ClearDisplayLoop2InnerLoopPeriod(interval) {
  $("#Loop2ButtonNextClick").html("");
}


function ClearDisplayNextPresetPeriod(interval) {
  $("#Loop2PresetNextChange").empty();
}

function DisplayLoop1Interval(interval) {
  $("#IntervalRandomNumber").html("The next button click is in: " + interval/1000 + " seconds.");
}

function ClearDisplayLoop1Interval(interval) {
  $("#IntervalRandomNumber").empty();
}

function RandomlyTimedButtonClick(min, max) {
  var interval = RandomIntervalInMS(min, max);
  window.setTimeout(function () {
    // check after random interval if loop1 is still checked before firing.
    if (IsLoop1Enabled()) {
      $('#getit').click();
      RandomlyTimedButtonClick(min, max);
    }
  }, interval);
  DisplayLoop1Interval(interval);
}

function RandomlyTimedButtonClick2(min, max) {
  var interval = RandomIntervalInMS(min, max);
  window.randomlyTimedButtonClick = window.setTimeout(function () {
    // check after random interval if loop1 is still checked before firing.
    if (IsLoop2Enabled()) {
      $('#getit').click();
      RandomlyTimedButtonClick2(min, max);
    }
  }, interval);
  DisplayLoop2InnerLoopPeriod(interval);
}


function IsLoop1Enabled() {
  return $("input#loop1[type=checkbox]").is(":checked");
}

function IsLoop2Enabled() {
  return $("input#loop2[type=checkbox]").is(":checked");
}

function PopulatePresetValue(preset, input) {
  var key = input.className;
  if (preset[key]) {
    $(input).val(preset[key]);
  }
}

function PopulatePreset(presetId) {
  // Take a set of presets and apply them to the UI fields.
  var presetValues = CameraPresets[presetId],
    columns = $('.column'),
    key;

  columns.each(function (cIndex, col) {
    var preset = presetValues[cIndex];
    $(col).find('input').each(function (iIndex, input) {
      PopulatePresetValue(preset, input);
    });
  });
}

function IsRangeValid(low, high) {
  return IsNumeric(low) && IsNumeric(high) && low <= high;
}

function RandomInRange(low, high) {
  var adjustedHigh;

  if(IsRangeValid(low, high)) {
    adjustedHigh = (high - low) + 1;
    return Math.floor(Math.random () * adjustedHigh) + low;
  } else {
    return NaN;
  }
}

function ApplySettings(settings, cameraNode) {
  var p = settings.p,
    t = settings.t,
    z = settings.z;

  if (IsNumeric(p) && IsNumeric(t) && IsNumeric(z)) {
    $(cameraNode).find('.cameraFrame').attr('src', CameraUrl(cameraNode, settings));
  }
}

function UserFeedback(setting, node) {
  if (IsNumeric(setting)) {
    $(node).text(setting);
  } else {
    $(node).text("Careful now...");
  }
}

function ScopedNode(context, node) {
  // Return a function that scopes jQuery DOM queries to a specific node.
  return function (node) {
    return $(context).find(node);
  };
}

function CollectCameraSettings(cameraNode) {
  var $find = ScopedNode(cameraNode);

  var PnumRand = RandomInRange(ParsedFloatOf($find(".Plownumber")), ParsedFloatOf($find(".Phighnumber")));
  var TnumRand = RandomInRange(ParsedFloatOf($find(".Tlownumber")), ParsedFloatOf($find(".Thighnumber")));
  var ZnumRand = RandomInRange(ParsedFloatOf($find(".Zlownumber")), ParsedFloatOf($find(".Zhighnumber")));

  UserFeedback(PnumRand, $find('.Prandomnumber'));
  UserFeedback(TnumRand, $find('.Trandomnumber'));
  UserFeedback(ZnumRand, $find('.Zrandomnumber'));

  return {
    p: PnumRand,
    t: TnumRand,
    z: ZnumRand
  };
}

function CameraUrl(cameraNode, settings) {
  var baseUrl = $(cameraNode).find('.cameraFrame').attr('baseUrl');
  return baseUrl + "&pan=" + settings.p +"&tilt=" + settings.t +"&zoom=" + settings.z;
}

$(function () {

  $("#getit").click(function () {
    $('.camera').each(function (index, cameraNode) {
      ApplySettings(CollectCameraSettings(cameraNode), cameraNode);
    });
  });

  $("button.preset").click(function (event) {
    PopulatePreset(event.target.id);
    $("#getit").click();
  });

  $("input[type=text]").each(function () {
    $(this).data("first-click", true);
  });

  $("input[type=text]").focus(function () {
    if ($(this).data("first-click")) {
      $(this).val("");
      $(this).data("first-click", false);
      $(this).css("color", "black");
    }
  });

  $("input#loop1").change(function () {
    var min, max;

    if(IsLoop1Enabled()) {
      min = parseInt($("#minRandomSeconds").val());
      max = parseInt($("#maxRandomSeconds").val());
      if (IsNumeric(min) && IsNumeric(max)) {
        RandomlyTimedButtonClick(min, max);
      }
    } else {
      ClearDisplayLoop1Interval();
    }
  });

  $("input#loop2").change(function () {
    var presets = [];
    ClearDisplayNextPresetPeriod();
    ClearDisplayLoop2InnerLoopPeriod();

    if (IsLoop2Enabled()) {
      presets = CollectLoop2Presets().map(ParsePreset);
      PopulatePreset("preset" + presets[0].index);
      DisplayNextPresetPeriod(presets, 0);
      $("#getit").click();
      StartUpdatePresetsLoop(presets);
    } else {
      StopUpdatePresetsLoop();
    }
  });

});
