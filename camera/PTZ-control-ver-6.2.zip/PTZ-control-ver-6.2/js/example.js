// Set camera preset values here.  For each preset, the first set of values is
// for the left column, and the second set of values is for the right column.
var CameraPresets = {
  preset1: [
    { Plownumber: -1854, Phighnumber: -1258, Tlownumber: -657, Thighnumber: 12339, Zlownumber: 51468, Zhighnumber: 64711 },
    { Plownumber: -10603, Phighnumber: 74, Tlownumber: -14364, Thighnumber: -3627, Zlownumber: 74271, Zhighnumber: 150835 }
  ],
  preset2: [
    { Plownumber: -16277, Phighnumber: -12267, Tlownumber: -14402, Thighnumber: 11052, Zlownumber: 131714, Zhighnumber: 219794 },
    { Plownumber: -13149, Phighnumber: -6575, Tlownumber: -9813, Thighnumber: 1392, Zlownumber: 140826, Zhighnumber: 162393 }
  ],
  preset3: [
    { Plownumber: -9481, Phighnumber: 12514, Tlownumber: -6998, Thighnumber: -187, Zlownumber: 164451, Zhighnumber: 194106 },
    { Plownumber: -10197, Phighnumber: -1905, Tlownumber: -5594, Thighnumber: 7405, Zlownumber: 186608, Zhighnumber: 275870 }
  ],
  preset4: [
    { Plownumber: -7584, Phighnumber: 8831, Tlownumber: 11523, Thighnumber: 15369, Zlownumber: 254, Zhighnumber: 162396 },
    { Plownumber: -7470, Phighnumber: 12938, Tlownumber: -10398, Thighnumber: 4867, Zlownumber: 57431, Zhighnumber: 152027 }
  ]
};

// Utility Function for making a random preset.  Not used in code anywhere, but useful for developing
function RandomizedPreset() {
  var p, z, t;

  p = [ Math.floor(Math.random() * 34000) -17000, Math.floor(Math.random() * 34000) -17000 ];
  t = [ Math.floor(Math.random() * 34000) -17000, Math.floor(Math.random() * 34000) -17000 ];
  z = [ Math.floor(Math.random() * 300000) + 1, Math.floor(Math.random() * 300000) + 1 ];

  return {
    Plownumber: Math.min(p[0], p[1]),
    Phighnumber: Math.max(p[0], p[1]),
    Tlownumber: Math.min(t[0],t[1]),
    Thighnumber: Math.max(t[0], t[1]),
    Zlownumber: Math.min(z[0], z[1]),
    Zhighnumber: Math.max(z[0], z[1])
  };
}

function Camera (selector) {
  this.selector = selector;
  this.node = $(selector);
  this.loop1UpdateTimer = null;
  this.loop2PresetTimer = null;
  this.loop2UpdateTimer = null;

  this.clearDisplayLoop1Interval = function (interval) {
    this.node.find(".IntervalRandomNumber").empty();
  };

  this.displayLoop1Interval = function (interval) {
    this.node.find(".IntervalRandomNumber").html("update in " + interval/1000 + " secs");
  };

  this.startLoop1 = function () {
    this.clearDisplayLoop1Interval();
    var min = parseInt(this.node.find(".minRandomSeconds").val());
    var max = parseInt(this.node.find(".maxRandomSeconds").val());
    if (IsNumeric(min) && IsNumeric(max)) {
      this.loop1UpdateTimer = RandomlyTimedButtonClick(min, max, this);
    }
  };

  this.startUpdatePresetsLoop = function(presets) {
    var minInterval = 1,
        maxInterval = 10;

    // first run (at 0ms);
    this.updatePresets(presets, 0);

    // start randomly clicking the button
    RandomlyTimedButtonClick2(minInterval, maxInterval, this);

    // subsequent 'timed' runs
    window.loop2EventLoop = this.scheduleUpdatePresets(presets, 1);
  };

  this.isLoop2Enabled = function () {
    return this.node.find('input.loop2').is(':checked');
  };

  this.updatePresets = function(presets, currentIndex) {
    if(this.isLoop2Enabled()) {
      this.populatePreset("preset" + presets[currentIndex].index);
      this.displayNextPresetPeriod(presets, currentIndex);
      this.collectAndUpdateSettings();
      this.loop2PresetTimer = this.scheduleUpdatePresets(presets, currentIndex);
    }
  };

  this.scheduleUpdatePresets = function(presets, currentIndex) {
    // Outer event loop.  Controls when we change rows in Loop2; e.g., which preset.
    var self = this;
    return window.setTimeout(function () {
      self.updatePresets(presets, SafeNextIndex(presets, currentIndex));
    }, presets[currentIndex].period * 1000);
  };

  this.stopLoop1 = function () {
    this.clearDisplayLoop1Interval();
    window.clearTimeout(this.loop1UpdateTimer);
  };

  this.index = function () {
    return parseInt(this.node.attr('id').replace('camera', '')) - 1;
  };

  this.startLoop2 = function () {
    this.clearDisplayNextPresetPeriod();
    this.clearDisplayLoop2InnerLoopPeriod();
    presets = Loop2.settings(this.node);
    this.populatePreset("preset" + presets[0].index);
    this.displayNextPresetPeriod(presets, 0);
    this.collectAndUpdateSettings();
    this.startUpdatePresetsLoop(presets);
  };

  this.populatePreset = function (presetId) {
    // Take a set of presets and apply them to the UI fields.
    var presetValues = CameraPresets[presetId],
      preset = presetValues[this.index()],
      self = this;

    this.node.find('.setting input').each(function (index, input) {
      self.populatePresetValue(preset, input);
    });
  };

  this.populatePresetValue = function (preset, input) {
    var key = input.className;
    if (preset[key]) {
      $(input).val(preset[key]);
    }
  };

  this.clearDisplayNextPresetPeriod = function(interval) {
    this.node.find(".Loop2PresetNextChange").empty();
  };

  this.clearDisplayLoop2InnerLoopPeriod = function(interval) {
    this.node.find(".Loop2ButtonNextClick").empty();
  };

  this.displayNextPresetPeriod = function(presets, index) {
    var interval = presets[index].period,
        currentIndex = index + 1,
        nextIndex = SafeNextIndex(presets, index) + 1;
    this.node.find(".Loop2PresetNextChange").html("row " +  nextIndex + " in " + interval + " secs");
  };

  this.displayLoop2InnerLoopPeriod = function(interval) {
    this.node.find(".Loop2ButtonNextClick").html("update in " + interval/1000 + " secs");
  };

  this.stopLoop2 = function () {
    this.clearDisplayNextPresetPeriod();
    this.clearDisplayLoop2InnerLoopPeriod();
    window.clearTimeout(this.loop2PresetTimer);
    window.clearTimeout(this.loop2UpdateTimer);
  };

  this.collectAndUpdateSettings = function () {
    UpdateCameraSettings(CollectCameraSettings(this.node), this.node);
  };

}

function Cameras() {
  array = [].concat(Array.prototype.slice.call(arguments));
  array.findByDomNode = function (node) {
    return array.find(function (camera) {
      return $(node).parents(camera.selector).length === 1;
    });
  };
  return array;
}



function IsNumeric(n) {
  return !isNaN(n);
}


function LoopingArray() {
  array = [].concat(Array.prototype.slice.call(arguments));
  array.currentIndex = 0;

  array.nextIndex = function () {
    if (this.length === 0) {
      return undefined;
    }

    return (this.currentIndex + 1 >= array.length) ? 0 : this.currentIndex + 1;
  };

  array.next = function () {
    this.currentIndex = this.nextIndex();
    return this[this.currentIndex];
  };

  return array;
}



Loop2 = {
  pluckValues: function (inputGroup) {
    $find = ScopedNode($(inputGroup));
    return {
      index: ParsedIntOf($find('.index')),
      period: ParsedIntOf($find('.period'))
    };
  },

  settings: function (node) {
    return $.makeArray(node.find(".loop2Preset")).map(Loop2.pluckValues);
  }
};


function SafeNextIndex(array, currentIndex) {
  // Return next index, or loop back to 0 if next is out of bounds.
  return (currentIndex + 1 >= array.length) ? 0 : currentIndex + 1;
}

function RandomIntervalInMS(min, max) {
  return Math.floor((Math.random() * max) + min) * 1000;
}

function ParsedIntOf(input) {
  var parsed = parseInt($(input).val());
  return (IsNumeric(parsed)) ? parsed : NaN;
}

function ParsedFloatOf(input) {
  var parsed = parseFloat($(input).val());
  return (IsNumeric(parsed)) ? parsed : NaN;
}


function RandomlyTimedButtonClick(min, max, camera) {
  var interval = RandomIntervalInMS(min, max);
  // don't reloop if the checkbox is not enabled
  if(camera.node.find('input.loop1').is(':checked')) {
    camera.displayLoop1Interval(interval);
    return window.setTimeout(function () {
      camera.collectAndUpdateSettings();
      RandomlyTimedButtonClick(min, max, camera);
    }, interval);
  }
}

function RandomlyTimedButtonClick2(min, max, camera) {
  var interval = RandomIntervalInMS(min, max);

  if (camera.isLoop2Enabled()) {
    camera.displayLoop2InnerLoopPeriod(interval);
    return window.setTimeout(function () {
      camera.collectAndUpdateSettings();
      RandomlyTimedButtonClick2(min, max, camera);
    }, interval);
  }
}



function Range(low, high) {

  this.low = low;
  this.high = high;

  this.adjustedHigh = function() {
    return (this.high - this.low) + 1;
  };

  this.isValid = function () {
    return IsNumeric(this.low) && IsNumeric(this.high) && this.low <= this.high;
  };

  this.random = function(){
    if(this.isValid()) {
      return Math.floor(Math.random () * this.adjustedHigh()) + this.low;
    } else {
      return NaN;
    }
  };
}

function UpdateCameraSettings(settings, cameraNode) {
  var p = settings.p,
    t = settings.t,
    z = settings.z;

  if (IsNumeric(p) && IsNumeric(t) && IsNumeric(z)) {
    $(cameraNode).find('.cameraFrame').attr('src', CameraUrl(cameraNode, settings));
  }
}

function Validate(setting, node) {
  if (IsNumeric(setting)) {
    $(node).text(setting);
  } else {
    $(node).text("Careful now...");
  }
}

function ScopedNode(context, node) {
  // Return a function that scopes jQuery DOM queries to a specific node.
  return function (node) {
    return $(context).find(node);
  };
}

function CollectCameraSettings(cameraNode) {
  var $find = ScopedNode(cameraNode);

  var PnumRand = new Range(ParsedFloatOf($find(".Plownumber")), ParsedFloatOf($find(".Phighnumber"))).random();
  var TnumRand = new Range(ParsedFloatOf($find(".Tlownumber")), ParsedFloatOf($find(".Thighnumber"))).random();
  var ZnumRand = new Range(ParsedFloatOf($find(".Zlownumber")), ParsedFloatOf($find(".Zhighnumber"))).random();

  Validate(PnumRand, $find('.Prandomnumber'));
  Validate(TnumRand, $find('.Trandomnumber'));
  Validate(ZnumRand, $find('.Zrandomnumber'));

  return {
    p: PnumRand,
    t: TnumRand,
    z: ZnumRand
  };
}

function CameraUrl(cameraNode, settings) {
  var baseUrl = $(cameraNode).find('.cameraFrame').attr('baseUrl');
  return baseUrl + "&pan=" + settings.p +"&tilt=" + settings.t +"&zoom=" + settings.z;
}

$(function () {

  // A camera is represeted by a set of DOM nodes, including the iframe that
  // displays the picture and a set of inputs with the settings.
  var cameras = new Cameras(new Camera('#camera1'), new Camera('#camera2'));

  $("#getit").click(function () {
    cameras.forEach(function (camera) {
      camera.collectAndUpdateSettings();
    });
  });

  $("button.preset").click(function (event) {
    cameras.forEach(function (camera) {
      camera.populatePreset(event.target.id);
      camera.collectAndUpdateSettings();
    });
  });

  $("input[type=text]").each(function () {
    $(this).data("first-click", true);
  });

  $("input[type=text]").focus(function () {
    if ($(this).data("first-click")) {
      $(this).val("");
      $(this).data("first-click", false);
      $(this).css("color", "black");
    }
  });

  $(".column.camera input.loop1").change(function () {
    var currentCamera = cameras.findByDomNode(this);

    if($(this).is(":checked")) {
      currentCamera.startLoop1();
    } else {
      currentCamera.stopLoop1();
    }
  });

  $(".column.camera input.loop2").change(function () {
    var currentCamera = cameras.findByDomNode(this);

    if($(this).is(":checked")) {
      currentCamera.startLoop2();
    } else {
      currentCamera.stopLoop2();
    }
  });

  $(".column.controls input.loop1").change(function () {

    if ($(this).is(":checked")) {
      $(".column.camera input.loop1").each(function (index, element) {
        if(!$(element).is(":checked")) {  $(element).click().trigger('change'); }
      });
    } else {
      $(".column.camera input.loop1").each(function (index, element) {
        if($(element).is(":checked")) {  $(element).click().trigger('change'); }
      });
    }
  });

  $(".column.controls input.loop2").change(function () {
    if ($(this).is(":checked")) {
      $(".column.camera input.loop2").each(function (index, element) {
        if(!$(element).is(":checked")) {  $(element).click().trigger('change'); }
      });
    } else {
      $(".column.camera input.loop2").each(function (index, element) {
        if($(element).is(":checked")) {  $(element).click().trigger('change'); }
      });
    }
  });

});
