// Set camera preset values here.  For each preset, the first set of values is
// for the left column, and the second set of values is for the right column.
var CameraPresets = {
  preset1: [
    { Plownumber: 1234, Phighnumber: 1234, Tlownumber: 1, Thighnumber: 3, Zlownumber: 1, Zhighnumber: 5 },
    { Plownumber: -1211, Phighnumber: 1111, Tlownumber: -1111, Thighnumber: 111, Zlownumber: 1111, Zhighnumber: 1111 }
  ],
  preset2: [
    { Plownumber: 22222, Phighnumber: 22222, Tlownumber: 22222, Thighnumber: 22222, Zlownumber: 22222, Zhighnumber: 22222 },
    { Plownumber: 333333, Phighnumber: 333333, Tlownumber: 333333, Thighnumber: 333333, Zlownumber: 333333, Zhighnumber: 333333 }
  ],
  preset3: [
    { Plownumber: 1234, Phighnumber: 1234, Tlownumber: 1, Thighnumber: 3, Zlownumber: 1, Zhighnumber: 5 },
    { Plownumber: 1234, Phighnumber: 1234, Tlownumber: 1, Thighnumber: 3, Zlownumber: 1, Zhighnumber: 5 }
  ],
  preset4: [
    { Plownumber: 1234, Phighnumber: 1234, Tlownumber: 1, Thighnumber: 3, Zlownumber: 1, Zhighnumber: 5 },
    { Plownumber: 1234, Phighnumber: 1234, Tlownumber: 1, Thighnumber: 3, Zlownumber: 1, Zhighnumber: 5 }
  ]
}

function IsNumeric(n) {
  return !isNaN(n);
}

function SafeNextIndex(array, currentIndex) {
  // Return next index, or loop back to 0 if next is out of bounds.
  return (currentIndex + 1 >= array.length) ? 0 : currentIndex + 1;
}

function RandomIntervalInSeconds(min, max) {
  return Math.floor((Math.random() * max) + min) * 1000;
}

function ParsedIntOf(input) {
  var parsed = parseInt($(input).val());
  return (IsNumeric(parsed)) ? parsed : NaN;
}

function ParsedFloatOf(input) {
  var parsed = parseFloat($(input).val());
  return (IsNumeric(parsed)) ? parsed : NaN;
}

function ParsePreset(inputGroup) {
  return {
    index: ParsedIntOf($(inputGroup).find('.index')),
    period: ParsedIntOf($(inputGroup).find('.period'))
  };
}

function CollectLoop2Presets() {
  return $.makeArray($(".loop2Preset"));
}

function Loop2Event(presets, currentIndex) {
  if(IsLoop2Enabled()) {
    currentIndex = SafeNextIndex(presets, currentIndex);
    PopulatePreset("preset" + presets[currentIndex].index);
    DisplayLoop2Period(presets[currentIndex].period);
    $("#getit").click();
    ScheduleLoop2Event(presets, currentIndex);
  }
}

function ScheduleLoop2Event(presets, currentIndex) {
  return window.setTimeout(function () {
    Loop2Event(presets, currentIndex || 0);
  }, presets[currentIndex].period * 1000);
}

function StartLoop2EventLoop(instructions) {
  window.loop2EventLoop = ScheduleLoop2Event(instructions, 0);
}

function StopLoop2EventLoop() {
  window.clearTimeout(window.loop2EventLoop);
}

function DisplayLoop2Period(interval) {
  $("#PeriodicUpdateTimer").html("The next preset update is in: " + interval + " seconds.");
}

function ClearDisplayLoop2Period(interval) {
  $("#PeriodicUpdateTimer").empty();
}

function DisplayLoop1Interval(interval) {
  $("#IntervalRandomNumber").html("The next button click is in: " + interval/1000 + " seconds.");
}

function ClearDisplayLoop1Interval(interval) {
  $("#IntervalRandomNumber").empty();
}

function RandomlyTimedButtonClick(min, max) {
  var interval = RandomIntervalInSeconds(min, max);
  window.setTimeout(function () {
    // check after random interval if loop1 is still checked before firing.
    if (IsLoop1Enabled()) {
      $('#getit').click();
      RandomlyTimedButtonClick(min, max);
    }
  }, interval);
  DisplayLoop1Interval(interval);
}

function IsLoop1Enabled() {
  return $("input#loop1[type=checkbox]").is(":checked");
}

function IsLoop2Enabled() {
  return $("input#loop2[type=checkbox]").is(":checked");
}

function PopulatePresetValue(preset, input) {
  var key = input.className;
  if (preset[key]) {
    $(input).val(preset[key]);
  }
}

function PopulatePreset(presetId) {
  var presetValues = CameraPresets[presetId],
    columns = $('.column'),
    key;

  columns.each(function (cIndex, col) {
    var preset = presetValues[cIndex];
    $(col).find('input').each(function (iIndex, input) {
      PopulatePresetValue(preset, input);
    });
  });
}

function IsRangeValid(low, high) {
  return IsNumeric(low) && IsNumeric(high) && low <= high;
}

function RandomInRange(low, high) {
  var adjustedHigh;

  if(IsRangeValid(low, high)) {
    adjustedHigh = (high - low) + 1;
    return Math.floor(Math.random () * adjustedHigh) + low;
  } else {
    return NaN;
  }
}

function ApplySettings(settings, cameraNode) {
  var p = settings.p,
    t = settings.t,
    z = settings.z;

  if (IsNumeric(p) && IsNumeric(t) && IsNumeric(z)) {
    $(cameraNode).find('.cameraFrame').attr('src', CameraUrl(cameraNode, settings));
  }
}

function UserFeedback(setting, node) {
  if (IsNumeric(setting)) {
    $(node).text(setting);
  } else {
    $(node).text("Careful now...");
  }
}

function ScopedNode(context, node) {
  // Return a function that scopes jQuery DOM queries to a specific node.
  return function (node) {
    return $(context).find(node);
  }
}

function CollectCameraSettings(cameraNode) {
  var $find = ScopedNode(cameraNode);

  var PnumRand = RandomInRange(ParsedFloatOf($find(".Plownumber")), ParsedFloatOf($find(".Phighnumber")));
  var TnumRand = RandomInRange(ParsedFloatOf($find(".Tlownumber")), ParsedFloatOf($find(".Tlownumber")));
  var ZnumRand = RandomInRange(ParsedFloatOf($find(".Zlownumber")), ParsedFloatOf($find(".Zlownumber")));

  UserFeedback(PnumRand, $find('.Prandomnumber'));
  UserFeedback(TnumRand, $find('.Trandomnumber'));
  UserFeedback(ZnumRand, $find('.Zrandomnumber'));

  return {
    p: PnumRand,
    t: TnumRand,
    z: ZnumRand
  }
}

function CameraUrl(cameraNode, settings) {
  var baseUrl = $(cameraNode).find('.cameraFrame').attr('baseUrl');
  return baseUrl + "&pan=" + settings.p +"&tilt=" + settings.t +"&zoom=" + settings.z;
}

$(function () {

  $("#getit").click(function () {
    $('.camera').each(function (index, cameraNode) {
      ApplySettings(CollectCameraSettings(cameraNode), cameraNode);
    });
  });

  $("button.preset").click(function (event) {
    PopulatePreset(event.target.id);
  });

  $("input[type=text]").each(function () {
    $(this).data("first-click", true);
  });

  $("input[type=text]").focus(function () {
    if ($(this).data("first-click")) {
      $(this).val("");
      $(this).data("first-click", false);
      $(this).css("color", "black");
    }
  });

  $("input#loop1").change(function () {
    var min, max;

    if(IsLoop1Enabled()) {
      min = parseInt($("#minRandomSeconds").val());
      max = parseInt($("#maxRandomSeconds").val());
      if (IsNumeric(min) && IsNumeric(max)) {
        RandomlyTimedButtonClick(min, max);
      }
    } else {
      ClearDisplayLoop1Interval();
    }
  });

  $("input#loop2").change(function () {
    var presets = [];
    ClearDisplayLoop2Period();

    if (IsLoop2Enabled()) {
      presets = CollectLoop2Presets().map(ParsePreset);
      PopulatePreset("preset" + presets[0].index);
      DisplayLoop2Period(presets[0].period);
      $("#getit").click();
      StartLoop2EventLoop(presets);
    } else {
      StopLoop2EventLoop();
    }
  });

});
